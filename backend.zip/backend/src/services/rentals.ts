import mongoose from 'mongoose';
import { Rental } from '../models/student-actions/Rents';
import { AppError } from '../controllers/error';
import { combineFilters } from '../controllers/middleware';

// TODO: verify if actual move-in/out dates are needed
// No activities field yet
export type CreateRentalArguments = {
  studentId: mongoose.Types.ObjectId;
  unitId: mongoose.Types.ObjectId;

  applicationId: mongoose.Types.ObjectId;

  expectedMoveInDate?: Date | null;
  expectedMoveOutDate?: Date | null;
};

// No activities field yet
export type UpdateRentalArguments = {
  status?: string | null;

  expectedMoveInDate?: Date | null;
  expectedMoveOutDate?: Date | null;
  actualMoveInDate?: Date | null;
  actualMoveOutDate?: Date | null;
};

export const createRental = async (data: CreateRentalArguments) => {
  if (
    data.expectedMoveInDate &&
    data.expectedMoveOutDate &&
    data.expectedMoveInDate > data.expectedMoveOutDate
  ) {
    throw new AppError(422, 'Expected move-out date should not be before expected move-in date.');
  }

  const newRental = new Rental({
    studentId: data.studentId,
    unitId: data.unitId,

    applicationId: data.applicationId,

    expectedMoveInDate: data.expectedMoveInDate,
    expectedMoveOutDate: data.expectedMoveOutDate,
  });

  return await newRental.save();
};

export const getRentals = async () => {
  return await Rental.find();
};

export const updateRental = async (
  rentalId: mongoose.Types.ObjectId,
  data: UpdateRentalArguments,
  filters: any,
) => {
  const rental = await Rental.findOne(combineFilters(filters, { _id: rentalId }));

  if (!rental) {
    const rentalNoFilter = await Rental.findById(rentalId);

    if (rentalNoFilter) {
      throw new AppError(403, 'You cannot edit this rental.');
    } else {
      throw new AppError(404, 'Rental not found.');
    }
  }

  if (
    data.expectedMoveInDate &&
    data.expectedMoveOutDate &&
    data.expectedMoveInDate > data.expectedMoveOutDate
  ) {
    throw new AppError(422, 'Expected move-out date should not be before expected move-in date.');
  }

  if (
    data.actualMoveInDate &&
    data.actualMoveOutDate &&
    data.actualMoveInDate > data.actualMoveOutDate
  ) {
    throw new AppError(422, 'Actual move-out date should not be before actual move-in date.');
  }

  rental.set(data);

  return await rental.save();
};

export const deleteRental = async (rentalId: mongoose.Types.ObjectId, filters: any) => {
  const rental = await Rental.findOne(combineFilters(filters, { _id: rentalId }));

  if (!rental) {
    const rentalNoFilter = await Rental.findById(rentalId);

    if (rentalNoFilter) {
      throw new AppError(403, 'You cannot delete this rental.');
    } else {
      throw new AppError(404, 'Rental not found.');
    }
  }

  return await rental.deleteOne();
};

export const getRentalsByUnitId = async (
  unitId: mongoose.Types.ObjectId,
  filters: any
) => {
  const rentals = await Rental.find(combineFilters(filters, { unitId }));

  if (!rentals) {
    const rentalsNoFilter = await Rental.find({ unitId });

    if (rentalsNoFilter) {
      throw new AppError(403, 'You don\'t have permission to view these rentals.');
    } else {
      throw new AppError(404, 'Rentals not found.')
    }
  }

  return rentals;
};
